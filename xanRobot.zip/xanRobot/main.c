#include<stdio.h>
#include<stdlib.h>
//#include<winsock2.h>
//#include<mysql.h>
//#include<time.h>

	int i,j,initial,n,m;
	int sum	=0;
	int sumlost=10000;
	int placed[100];
    initial=10000; // initial stake

int main(){

//MYSQL *conn;
//conn = mysql_init(0);
//conn = mysql_real_connect(conn,"localhost","root","","xanrobot",0,NULL,0);
//if(conn){
//    printf("xanrobot launched successfully\n\n");
//}
//else {printf("you are offline!\n\n");
// exit(0);
//  }

int A[400]={1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
           1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0};  // data for 5 months
		   
int B[100]= {1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
           1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1};
		   
int C[5]= {1,1,0,1,1};

	printf("=======| XANROBOT |=======\n\n");

  int total= bankroll();
  //printf("\ntotal cash needed for 4 times is %d\n",total);

	Decision(B,100);
//	Decision(C,5);



}

int bankroll(){

       for(i=0;i<4;i++){
	printf("%d: %d\n",(i+1),sumlost);

		placed[i]=sumlost;

		//for loop for calculating the sum.
		for(j=i;j<=i;j++){
			sum+=placed[j];
		}

		sumlost=(sum+3100)/0.35;

	}

			return sum;
}

void Decision(int arr[], int n){
 int currentbal=750000;
 int lost=initial;
 int sum1=0, loss=0;
 int placed1[100];

	printf("");


		   for(i=0;i<n;i++){

		   	if(arr[i]==0){
		   		
		   		 placed1[i]=lost;
		   		 
		   			for(j=i;j<=i;j++){   //for loop for calculating the sum.
			sum1+=placed1[j];

		}
		int profit = currentbal-750000;
		
		if(sum1>140000){
			if(profit>sum1){ 
			   loss = placed1[i];
			   printf("\n you lost 3 times\n your balance from profit is %d this is the average breaking point",profit-sum1);
			   lost=initial;   //decision when profit is greater than what we lost
			    sum1 = 0;
			}  
			
			else{
			printf("\n you lost 3 times\n balance from profit is %d this is the average breaking point",profit-sum1);
			
			// for(m=0;m<2<m++){
			 	
			 	loss = placed1[i];
				lost=placed1[i-1];      //make decision after losing with small profit
				sum1=0;
			 //}
			 
			}
			}
      else{
	  
		 lost=(sum1+3100)/0.35;
    	 loss=placed1[i];
		       }
    	 
    	 currentbal= currentbal-loss;
    	 
			   }   

   else if(arr[i]==1){
   	
   	      sum1=0;   
   	  int win= (1.35*lost)-lost;
   	   currentbal=currentbal+win;
	   lost=initial;
	  

      }

	}
        printf("\n\n\t\t\t\t\t\tbalance: %d\n",currentbal);
		printf("you're placing %d next.\n",lost);

}

//void finish_with_error(MYSQL*conn){
//fprintf(stderr,"%s\n",mysql_error(conn));
//mysql_close(conn);
//exit(1);
//}

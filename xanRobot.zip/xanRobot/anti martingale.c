#include<stdio.h>
#include<stdlib.h>
//#include<winsock2.h>
//#include<mysql.h>
//#include<time.h>

	int i,j,initial,n;
	int sum	=0;
	int sumlost=10000;
	int placed[10];
    initial=10000; // initial stake

int main(){

//MYSQL *conn;
//conn = mysql_init(0);
//conn = mysql_real_connect(conn,"localhost","root","","xanrobot",0,NULL,0);
//if(conn){
//    printf("xanrobot launched successfully\n\n");
//}
//else {printf("you are offline!\n\n");
// exit(0);
//  }

	int A[100]= {1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
           1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,1,1,0,
		   1,1,0,1,1,1,1,1,0,0,1,1,0,1,1,1,0,0,1,0};

	printf("=======| XANROBOT |=======\n\n");

  int total= bankroll();
  printf("\ntotal cash needed for 4 times is %d\n",total);

	Decision(A,100);



}

int bankroll(){

       for(i=0;i<4;i++){
	printf("%d: %d\n",(i+1),sumlost);

		placed[i]=sumlost;

		//for loop for calculating the sum.
		for(j=i;j<=i;j++){
			sum+=placed[j];
		}

		sumlost=(sum+3100)/0.35;

	}

			return sum;
}

void Decision(int arr[], int n){
 int stake=10000;
 int currentbal=750000;
 int lost=stake;
 int sum1=0;
 int placed1[10];

	printf("");

		   for(i=0;i<n;i++){

		   	if(arr[i]==1){

//		   placed1[i]=lost;
//		for(j=i;j<=i;j++){   //for loop for calculating the sum.
//			sum1+=placed1[j];
//		}
//		lost=(sum1+3100)/0.35;
		lost=lost*2;
		
		int win= (1.35*lost)-lost;
		currentbal=currentbal+win;
			   }

   else if(arr[i]==0){
   	   sum1=0;    //reset the sum of lost to zero.
   	   currentbal= currentbal-lost;
	   lost=lost*0.3;
      }

	}
        printf("your current balance is %d\n",currentbal);
		printf("you're placing %d next.\n",lost);

}

//void finish_with_error(MYSQL*conn){
//fprintf(stderr,"%s\n",mysql_error(conn));
//mysql_close(conn);
//exit(1);
//}


print("====ARBITRAGE CALCULATOR====")

odd1= float(input("enter your first odd:"))
odd2= float(input("enter your second odd:"))
 
stake = float(input("enter your stake:"))
arb1 = (1/odd1)*100
arb2 = (1/odd2)*100

print("your percentage arbitrage is:",arb1+arb2)

stake1= (arb1/(arb1+arb2))*stake
stake2= stake-stake1

print("stake in the first slot is",stake1)
print("stake in the second slot is",stake2)


win = stake1*odd1
profit = win-stake

print("the profit you made is",profit)

#option=
 

#include<stdio.h>
int main(){
		float odd1, odd2, stake, stake1,stake2,arb1,arb2,win,arb,profit;
		char option;
	
	for(;;){
		
		printf("\n\n===========ARBITRAGE CALCULATOR===========\n\n");

	printf("enter your first odd\n");
	scanf("%f",&odd1);
	
	printf("enter your second odd\n");
	scanf("%f",&odd2);
	
	printf("enter your stake\n");
	scanf("%f",&stake);
	printf("\n\n");
	
	arb1 = (1/odd1)*100;
	arb2 = (1/odd2)*100;
	arb = arb1+arb2;
	printf("the percentage arbitrage is %.2f\n\n",arb);
	
	stake1 = (arb1/arb)*stake;
	stake2 = stake-stake1;
	
	printf("stake for the first price :%.0f\n",stake1);
	printf("stake for the second price :%.0f\n\n",stake2);

	win= stake1*odd1; // or odd2*stake2
	profit =  win-stake;
	
	fflush(stdin);
	printf("your profit in this case will be:%.2f\n\n\n",profit);
	
	printf("do you wish to continue? Y/N \n");
	 option=getchar();
	  
	if(option=='N'||option=='n'){
		printf("thanks for using our calculator!\n");
			exit(1);
	} else {	}
		
	}
		
}
